SOP TBANG STORE - WEBSITE PACKAGE

Cach dung:
1. Giai nen file ZIP.
2. Tai thu muc SOP_TBANG_STORE_MUSIC_PACKAGE len Netlify (hoac deploy thu muc nay).
3. Mo website va cham nut “♫ Bat nhac” de phat nhac. iPhone/Safari yeu cau thao tac cham cua nguoi dung truoc khi phat am thanh.

Luu y ve am thanh:
- Goi ZIP nay co nut phat/tat va mot giai dieu dien tu mau duoc tao bang Web Audio, lap lai khi dang bat.
- Chua co file MP4/MP3 goc cua ban trong cac tep hien truy cap duoc, nen chua the nhung dung bai nhac ban da gui.
- Khi ban tai lai file MP4/MP3, co the thay giai dieu mau bang dung ban nhac do va dong goi lai.

Luu y: Goi nay la ban giao dien website. Ket noi Telegram bot, SePay/IPN va backend chua duoc cau hinh trong goi nay.
